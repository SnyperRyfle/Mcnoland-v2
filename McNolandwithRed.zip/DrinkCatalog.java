public class DrinkCatalog extends FoodCatalog {
    public DrinkCatalog() {
        for (DrinkType type : DrinkType.values()) {
            addItem(new FoodItem(type.getName(), type.getPrice()));
        }
    }
}