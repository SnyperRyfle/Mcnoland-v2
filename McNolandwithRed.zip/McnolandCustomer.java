class McnolandCustomer extends McnolandMain {
    private final String name;
    private final boolean isMember;
    private final OrderCatalog orderCatalog;

    public McnolandCustomer(String name, boolean isMember) {
        this.name = name;
        this.isMember = isMember;
        this.orderCatalog = new OrderCatalog();
    }

    public String getName() {
        return name;
    }

    public boolean isMember() {
        return isMember;
    }

    public OrderCatalog getOrderCatalog() {
        return orderCatalog;
    }

    public void displayCustomerInfo() {
        System.out.println("Customer: " + name);
        System.out.println("Member: " + (isMember ? "Yes" : "No"));
        orderCatalog.displayOrder();
    }
}