import java.util.ArrayList;
import java.util.List;

public class CustomerInfo extends McnolandMain {
    private final List<McnolandCustomer> customerList;

    public CustomerInfo() {
        customerList = new ArrayList<>();
    }

    public void addCustomer(McnolandCustomer customer) {
        customerList.add(customer);
    }

    public McnolandCustomer getCustomer(int index) {
        if (index >= 0 && index < customerList.size()) {
            return customerList.get(index);
        }
        return null;
    }

    public List<McnolandCustomer> getAllCustomers() {
        return customerList;
    }

    public void displayAllCustomers() {
        if (customerList.isEmpty()) {
            System.out.println("No customers to display.");
            return;
        }
        System.out.println("\n--- Customer List ---");
        for (int i = 0; i < customerList.size(); i++) {
            System.out.println("Customer #" + (i + 1) + ":");
            customerList.get(i).displayCustomerInfo();
        }
    }
}