import java.util.ArrayList;

public class BurgerCatalog extends FoodCatalog {
    public BurgerCatalog() {
        for (BurgerType type : BurgerType.values()) {
            addItem(new Burger(type));
        }
    }
}
