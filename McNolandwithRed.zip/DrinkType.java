public enum DrinkType {
    COKE("Coke: RM", 1.99),
    SPRITE("Sprite: RM", 1.99),
    ICED_LEMON_TEA("Iced Lemon Tea RM", 2.49),
    COFFEE("Coffee: RM", 2.99),
    ICED_MILO("Iced Milo: RM", 3.49);

    private final String name;
    private final double price;

    DrinkType(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }
}