import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class McnolandGUI extends Application {

    private final OrderCatalog orderCatalog = new OrderCatalog();
    private final BurgerCatalog burgerCatalog = new BurgerCatalog();
    private final DrinkCatalog drinkCatalog = new DrinkCatalog();
    private final TextArea orderSummaryArea = new TextArea();
    private final DessertCatalog dessertCatalog = new DessertCatalog();
    private final ComboCatalog comboCatalog = new ComboCatalog(burgerCatalog, drinkCatalog, dessertCatalog);

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Mcnoland Order System :)");

        VBox root = new VBox(10);
        root.setPadding(new Insets(15));
        root.setStyle("-fx-background-color: #FFF8E6;");

        // Title
        Label title = new Label("Welcome to Mcnoland!");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #DA291C;");

        // Create panes
        TitledPane burgerPane = createFoodSection("🍔 Burger Menu", burgerCatalog);
        TitledPane drinkPane = createFoodSection("🥤 Drink Menu", drinkCatalog);
        TitledPane dessertPane = createFoodSection("🍰 Dessert Menu", dessertCatalog);
        TitledPane comboPane = createFoodSection("🍱 Combo Meals", comboCatalog);

        // Order Summary
        orderSummaryArea.setEditable(false);
        orderSummaryArea.setPrefHeight(200);
        orderSummaryArea.setStyle("-fx-control-inner-background: #FFFFFF; -fx-border-color: #FFC72C;");
        updateOrderSummary();

        // Payment Button
        Button payButton = new Button("💰 Pay Now");
        payButton.setStyle("-fx-background-color: #DA291C; -fx-text-fill: #FFC72C; -fx-font-weight: bold; " +
                "-fx-font-size: 16px; -fx-padding: 10 25; -fx-background-radius: 20;");
        payButton.setOnAction(e -> {
            if (!orderCatalog.getOrderItems().isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Payment Successful");
                alert.setHeaderText("Order Paid");
                alert.setContentText("Total Paid: $" + String.format("%.2f", orderCatalog.calculateTotal()));

                DialogPane dialogPane = alert.getDialogPane();
                dialogPane.setStyle("-fx-background-color: #FFF8E6;");
                dialogPane.lookupButton(ButtonType.OK).setStyle("-fx-background-color: #DA291C; -fx-text-fill: white;");

                alert.showAndWait();
                orderCatalog.clearOrder();
                updateOrderSummary();
            }
        });

        // Add ALL components ONCE
        root.getChildren().addAll(burgerPane, drinkPane, dessertPane, comboPane, new Label("Current Order:"), orderSummaryArea, payButton);

        Scene scene = new Scene(root, 500, 650);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private TitledPane createFoodSection(String title, FoodCatalog catalog) {
        VBox foodList = new VBox(5);
        for (FoodItem item : catalog.getAllItems()) {
            HBox itemBox = new HBox(10);

            // Special display for combos
            String emoji = "🍔 "; // Default emoji
            if (item instanceof Drink) emoji = "🥤 ";
            else if (item instanceof Dessert) emoji = "🍰 ";
            else if (item instanceof ComboMeal) emoji = "🍱 ";

            Label nameLabel = new Label(emoji + item.getDisplayInfo());
            nameLabel.setStyle("-fx-font-weight: bold;");

            Spinner<Integer> quantitySpinner = new Spinner<>(0, 20, 0);
            quantitySpinner.setStyle("-fx-border-color: #FFC72C;");

            Button addButton = new Button("➕ Add");
            addButton.setStyle("-fx-background-color: #DA291C; -fx-text-fill: white; -fx-background-radius: 10;");

            Button removeButton = new Button("➖ Remove");
            removeButton.setStyle("-fx-background-color: #C8102E; -fx-text-fill: white; -fx-background-radius: 10;");

            addButton.setOnAction(e -> {
                int qty = quantitySpinner.getValue();
                if (qty > 0) {
                    orderCatalog.addOrder(item, qty);
                    updateOrderSummary();
                }
                quantitySpinner.getValueFactory().setValue(0);
            });

            removeButton.setOnAction(e -> {
                orderCatalog.removeOrder(item);
                updateOrderSummary();
            });

            itemBox.getChildren().addAll(nameLabel, quantitySpinner, addButton, removeButton);
            foodList.getChildren().add(itemBox);
        }

        TitledPane sectionPane = new TitledPane(title, foodList);
        sectionPane.setStyle("-fx-text-fill: #DA291C; -fx-font-weight: bold;");
        sectionPane.setExpanded(false);
        return sectionPane;
    }

    private void updateOrderSummary() {
        orderSummaryArea.setText(orderCatalog.getOrderSummary());
        orderSummaryArea.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
    }
}

